﻿const state = {
  data: {
    hero: {
      titlePrefix: 'BLACK',
      titleAccent: 'CAT',
      subtitle: 'Streetwear anime para destacar tu estilo.',
      badges: ['Desde $16.99', 'Anime Drop', 'Atencion personalizada'],
      image: ''
    },
    contacts: {
      whatsapp: '50361900185',
      instagram: 'blackcat.sivar',
      tiktok: '@blackcat.sivar',
      email: 'blackcat2811@hotmail.com'
    },
    products: []
  },
  filter: 'all',
  currentProduct: null,
  type: 'basic',
  size: 'M',
  color: 'Negro',
  qty: 1,
  cart: [],
  heroSlides: [],
  slideIndex: 0,
  slideTimer: null
};

const typeOptions = [
  { id: 'basic', label: 'Basica' },
  { id: 'oversize', label: 'Oversize' }
];

const sizeOptions = ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'];

const colorOptions = [
  { id: 'Blanco', style: 'background:#f1f1f1' },
  { id: 'Negro', style: 'background:#111' },
  { id: 'Beige', style: 'background:#d7c7aa' },
  { id: 'Gris', style: 'background:#8e96a3' }
];

const HERO_FALLBACK_SLIDES = [
  { image: 'mockups/frieren1.jpg', title: 'Drop Frieren', subtitle: 'Nueva coleccion' },
  { image: 'mockups/jujutsu1.jpg', title: 'Drop Jujutsu', subtitle: 'Tendencia' },
  { image: 'mockups/chainsaw1.jpg', title: 'Drop Chainsaw', subtitle: 'Edicion top' },
  { image: 'mockups/kaiju1.jpg', title: 'Drop Kaiju', subtitle: 'Stock limitado' }
];

const CATEGORY_FALLBACKS = [
  { name: 'Nuevos drops', image: 'mockups/frieren2.jpg', text: 'Coleccion destacada de temporada', filter: 'all' },
  { name: 'Jujutsu', image: 'mockups/jujutsu2.jpg', text: 'Modelos anime populares', filter: 'Jujutsu Kaisen' },
  { name: 'Chainsaw', image: 'mockups/chainsaw2.jpg', text: 'Diseños con alto contraste', filter: 'Chainsaw Man' },
  { name: 'Kaiju', image: 'mockups/kaiju2.jpg', text: 'Estilo urbano y minimal', filter: 'Kaiju No. 8' }
];

function formatPrice(value) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function getUnitPrice(type, size) {
  if (size === '2XL') return 23.99;
  if (size === '3XL') return 28.99;
  return type === 'oversize' ? 19.99 : 16.99;
}

function isSizeAvailable(type, size) {
  return !(type === 'oversize' && size === 'XS');
}

function getHeroSlides() {
  const collected = [];

  if (state.data.hero?.image) {
    collected.push({
      image: state.data.hero.image,
      title: 'BLACKCAT',
      subtitle: 'Hero principal'
    });
  }

  (state.data.products || [])
    .filter(p => p.image)
    .slice(0, 8)
    .forEach(p => {
      collected.push({
        image: p.image,
        title: p.title || 'Producto',
        subtitle: p.anime || 'Coleccion anime'
      });
    });

  HERO_FALLBACK_SLIDES.forEach(slide => collected.push(slide));

  const deduped = [];
  const seen = new Set();
  for (const slide of collected) {
    if (!slide.image || seen.has(slide.image)) continue;
    seen.add(slide.image);
    deduped.push(slide);
    if (deduped.length >= 6) break;
  }

  return deduped;
}

function updateHeroSlide() {
  const slides = document.querySelectorAll('.hero-slide');
  const dots = document.querySelectorAll('.slide-dot');

  slides.forEach((slide, index) => {
    slide.classList.toggle('active', index === state.slideIndex);
  });
  dots.forEach((dot, index) => {
    dot.classList.toggle('active', index === state.slideIndex);
  });
}

function setHeroSlide(index) {
  if (!state.heroSlides.length) return;
  const max = state.heroSlides.length - 1;
  state.slideIndex = index < 0 ? max : index > max ? 0 : index;
  updateHeroSlide();
}

function moveHeroSlide(step) {
  setHeroSlide(state.slideIndex + step);
}

function startHeroAutoplay() {
  if (state.slideTimer) clearInterval(state.slideTimer);
  if (state.heroSlides.length <= 1) return;

  state.slideTimer = setInterval(() => {
    moveHeroSlide(1);
  }, 4200);
}

function renderHeroSlider() {
  const slidesWrap = document.getElementById('heroSlides');
  const dotsWrap = document.getElementById('heroDots');
  if (!slidesWrap || !dotsWrap) return;

  state.heroSlides = getHeroSlides();

  if (!state.heroSlides.length) {
    slidesWrap.innerHTML = '';
    dotsWrap.innerHTML = '';
    return;
  }

  if (state.slideIndex >= state.heroSlides.length) state.slideIndex = 0;

  slidesWrap.innerHTML = state.heroSlides
    .map((slide, index) => `
      <div class="hero-slide ${index === state.slideIndex ? 'active' : ''}">
        <img src="${escapeHtml(slide.image)}" alt="${escapeHtml(slide.title)}" loading="lazy" />
      </div>
    `)
    .join('');

  dotsWrap.innerHTML = state.heroSlides
    .map((_, index) => `<button class="slide-dot ${index === state.slideIndex ? 'active' : ''}" data-slide-dot="${index}" aria-label="Ir al slide ${index + 1}"></button>`)
    .join('');

  dotsWrap.querySelectorAll('[data-slide-dot]').forEach(dot => {
    dot.addEventListener('click', () => {
      setHeroSlide(Number(dot.dataset.slideDot));
      startHeroAutoplay();
    });
  });

  updateHeroSlide();
  startHeroAutoplay();
}

function applyHero() {
  const hero = state.data.hero || {};
  const contacts = state.data.contacts || {};

  const heroHeading = document.getElementById('heroHeading');
  const heroSubtitle = document.getElementById('heroSubtitle');
  const badgeEls = document.querySelectorAll('.hero-badges span');

  if (heroHeading) {
    heroHeading.innerHTML = `${escapeHtml(hero.titlePrefix || 'BLACK')}<span class="gradient">${escapeHtml(hero.titleAccent || 'CAT')}</span>`;
  }

  if (heroSubtitle) {
    heroSubtitle.textContent = hero.subtitle || 'Streetwear anime para destacar tu estilo.';
  }

  (hero.badges || []).forEach((text, index) => {
    if (badgeEls[index]) badgeEls[index].textContent = text || badgeEls[index].textContent;
  });

  const igLinks = document.querySelectorAll('a[href*="instagram.com"]');
  igLinks.forEach(a => {
    a.href = `https://instagram.com/${contacts.instagram}`;
  });

  const tkLinks = document.querySelectorAll('a[href*="tiktok.com"]');
  tkLinks.forEach(a => {
    a.href = `https://tiktok.com/@${(contacts.tiktok || '').replace(/^@/, '')}`;
  });

  const waLinks = document.querySelectorAll('a[href*="wa.me"], .wa-pill');
  waLinks.forEach(a => {
    a.href = `https://wa.me/${contacts.whatsapp}`;
  });

  renderHeroSlider();
}

function filteredProducts() {
  const products = state.data.products || [];
  const list = state.filter === 'all'
    ? products
    : products.filter(p => p.anime === state.filter);

  return [...list].sort((a, b) => (a.title || '').localeCompare(b.title || ''));
}

function markSelectedProductCard(productId) {
  document.querySelectorAll('.shirt-card').forEach(card => {
    const id = card.dataset.productCardId;
    card.classList.toggle('is-selected', String(id) === String(productId));
  });
}

function buildQuickBuyMessage(product) {
  return [
    'Hola, quiero comprar este producto:',
    `Producto: ${product.title}`,
    `Personaje: ${product.character}`,
    `Anime: ${product.anime}`,
    'Tipo: Basica',
    'Talla: M',
    'Color: Negro',
    `Total: ${formatPrice(getUnitPrice('basic', 'M'))}`
  ].join('\n');
}

function quickBuy(productId) {
  const product = (state.data.products || []).find(p => String(p.id) === String(productId));
  if (!product) return;

  const message = encodeURIComponent(buildQuickBuyMessage(product));
  window.open(`https://wa.me/${state.data.contacts.whatsapp}?text=${message}`, '_blank');
}

function renderProducts() {
  const grid = document.getElementById('shirtGrid');
  if (!grid) return;

  const products = filteredProducts();

  if (!products.length) {
    grid.innerHTML = '<article class="panel shirt-card"><div class="shirt-body"><h3>No hay productos en esta categoria todavia.</h3><p class="shirt-meta">Prueba otro filtro o revisa mas tarde.</p></div></article>';
    return;
  }

  grid.innerHTML = products.map(product => {
    const selected = state.currentProduct?.id === product.id ? 'is-selected' : '';
    return `
      <article class="panel shirt-card ${selected}" data-product-card-id="${product.id}">
        <button class="shirt-media" data-open="${product.id}" aria-label="Ver ${escapeHtml(product.title)}">
          <img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.title)}" loading="lazy">
          <span class="shirt-badge">${escapeHtml(product.badge || 'TOP')}</span>
        </button>
        <div class="shirt-body">
          <div class="shirt-head">
            <div>
              <h3>${escapeHtml(product.title)}</h3>
              <p class="shirt-meta">${escapeHtml(product.anime)} | ${escapeHtml(product.character)}</p>
            </div>
            <div class="shirt-price">${formatPrice(getUnitPrice('basic', 'M'))}</div>
          </div>
          <div class="shirt-actions">
            <button class="card-action select" data-select="${product.id}">Seleccionar</button>
            <button class="card-action buy" data-buy="${product.id}">Comprar</button>
          </div>
        </div>
      </article>
    `;
  }).join('');

  grid.querySelectorAll('[data-open], [data-select]').forEach(button => {
    button.addEventListener('click', () => openProduct(button.dataset.open || button.dataset.select));
  });

  grid.querySelectorAll('[data-buy]').forEach(button => {
    button.addEventListener('click', () => quickBuy(button.dataset.buy));
  });
}

function getCategoryItems() {
  const products = state.data.products || [];
  if (!products.length) return CATEGORY_FALLBACKS;

  const grouped = new Map();
  products.forEach(product => {
    const anime = (product.anime || 'Coleccion').trim();
    if (!grouped.has(anime)) {
      grouped.set(anime, {
        name: anime,
        image: product.image,
        text: `Explora ${anime}`,
        filter: anime
      });
    }
  });

  const categories = Array.from(grouped.values()).slice(0, 8);
  if (!categories.length) return CATEGORY_FALLBACKS;

  if (categories.length < 4) {
    for (const fallback of CATEGORY_FALLBACKS) {
      categories.push(fallback);
      if (categories.length >= 4) break;
    }
  }

  return categories;
}

function applyCategoryFilter(filterValue) {
  state.filter = filterValue;
  renderFilters();
  renderProducts();

  const section = document.getElementById('catalogo');
  if (section) {
    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function renderCategories() {
  const wrap = document.getElementById('categoryGrid');
  if (!wrap) return;

  const categories = getCategoryItems();
  wrap.innerHTML = categories.map(item => `
    <button class="category-card" data-category-filter="${escapeHtml(item.filter)}" aria-label="Ver ${escapeHtml(item.name)}">
      <div class="category-media">
        <img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.name)}" loading="lazy" />
      </div>
      <div class="category-content">
        <h3>${escapeHtml(item.name)}</h3>
        <p>${escapeHtml(item.text)}</p>
        <span class="category-cta">Ver productos</span>
      </div>
    </button>
  `).join('');

  wrap.querySelectorAll('[data-category-filter]').forEach(button => {
    button.addEventListener('click', () => {
      const filter = button.dataset.categoryFilter || 'all';
      applyCategoryFilter(filter);
    });
  });
}

function renderFilters() {
  const wrap = document.getElementById('filterChips');
  if (!wrap) return;

  const series = [...new Set(
    (state.data.products || [])
      .map(p => (p.anime || '').trim())
      .filter(Boolean)
  )];

  const filters = ['Todos', ...series];

  wrap.innerHTML = filters.map(name => {
    const value = name === 'Todos' ? 'all' : name;
    const active = state.filter === value ? 'active' : '';
    return `<button class="filter ${active}" data-filter="${escapeHtml(value)}">${escapeHtml(name)}</button>`;
  }).join('');

  wrap.querySelectorAll('[data-filter]').forEach(button => {
    button.addEventListener('click', () => {
      state.filter = button.dataset.filter;
      renderFilters();
      renderProducts();
    });
  });
}

function renderTypeChoices() {
  const wrap = document.getElementById('typeChoices');
  wrap.innerHTML = typeOptions
    .map(option => `<button class="choice ${state.type === option.id ? 'active' : ''}" data-type="${option.id}">${option.label}</button>`)
    .join('');

  wrap.querySelectorAll('[data-type]').forEach(button => {
    button.addEventListener('click', () => {
      state.type = button.dataset.type;
      if (!isSizeAvailable(state.type, state.size)) state.size = 'S';
      renderTypeChoices();
      renderSizeChoices();
      updateModalPrice();
    });
  });
}

function renderSizeChoices() {
  const wrap = document.getElementById('sizeChoices');
  wrap.innerHTML = sizeOptions.map(size => {
    const available = isSizeAvailable(state.type, size);
    return `<button class="choice ${state.size === size ? 'active' : ''} ${available ? '' : 'disabled'}" data-size="${size}" ${available ? '' : 'disabled'}>${size}</button>`;
  }).join('');

  wrap.querySelectorAll('[data-size]').forEach(button => {
    button.addEventListener('click', () => {
      if (button.disabled) return;
      state.size = button.dataset.size;
      renderSizeChoices();
      updateModalPrice();
    });
  });
}

function applyPreviewColor() {
  return;
}

function renderColorChoices() {
  const wrap = document.getElementById('colorChoices');
  wrap.innerHTML = colorOptions
    .map(color => `<button title="${color.id}" class="choice ${state.color === color.id ? 'active' : ''}" data-color="${color.id}" style="${color.style}"></button>`)
    .join('');

  wrap.querySelectorAll('[data-color]').forEach(button => {
    button.addEventListener('click', () => {
      state.color = button.dataset.color;
      renderColorChoices();
      applyPreviewColor();
      updateModalPrice();
    });
  });
}

function updateModalPrice() {
  if (!state.currentProduct) return;

  const unit = getUnitPrice(state.type, state.size);
  const total = unit * state.qty;

  document.getElementById('qtyValue').textContent = state.qty;
  document.getElementById('modalPrice').textContent = `${formatPrice(unit)} | total ${formatPrice(total)}`;
  document.getElementById('addToCartBtn').disabled = false;
  document.getElementById('buyNowBtn').disabled = false;

  const product = state.currentProduct;
  const message = encodeURIComponent([
    'Hola, quiero pedir esta camisa:',
    `Producto: ${product.title}`,
    `Personaje: ${product.character}`,
    `Anime: ${product.anime}`,
    `Tipo: ${state.type === 'basic' ? 'Basica' : 'Oversize'}`,
    `Talla: ${state.size}`,
    `Color: ${state.color}`,
    `Cantidad: ${state.qty}`,
    `Total: ${formatPrice(total)}`
  ].join('\n'));

  document.getElementById('buyNowBtn').onclick = () => {
    window.open(`https://wa.me/${state.data.contacts.whatsapp}?text=${message}`, '_blank');
  };
}

function openProduct(id) {
  const product = state.data.products.find(item => String(item.id) === String(id));
  if (!product) return;

  state.currentProduct = product;
  state.type = 'basic';
  state.size = 'M';
  state.color = 'Negro';
  state.qty = 1;

  document.getElementById('modalImage').src = product.image;
  document.getElementById('modalImage').alt = product.title;
  document.getElementById('modalTitle').textContent = product.title;
  document.getElementById('modalSubtitle').textContent = `${product.character} | ${product.anime}`;

  renderTypeChoices();
  renderSizeChoices();
  renderColorChoices();
  applyPreviewColor();
  updateModalPrice();

  document.getElementById('productModal').classList.add('show');
  document.body.style.overflow = 'hidden';
  markSelectedProductCard(product.id);
}

function closeProduct() {
  document.getElementById('productModal').classList.remove('show');
  if (!document.getElementById('cartPanel').classList.contains('open')) {
    document.body.style.overflow = '';
  }
}

function addCurrentToCart() {
  const product = state.currentProduct;
  if (!product) return;

  const unitPrice = getUnitPrice(state.type, state.size);
  const key = [product.id, state.type, state.size, state.color].join('|');
  const existing = state.cart.find(item => item.key === key);

  if (existing) {
    existing.qty += state.qty;
  } else {
    state.cart.push({
      key,
      title: product.title,
      character: product.character,
      anime: product.anime,
      image: product.image,
      type: state.type,
      typeLabel: state.type === 'basic' ? 'Basica' : 'Oversize',
      size: state.size,
      color: state.color,
      qty: state.qty,
      unitPrice
    });
  }

  renderCart();
  closeProduct();
  openCart();
}

function renderCart() {
  const wrap = document.getElementById('cartItems');
  const totalCount = state.cart.reduce((sum, item) => sum + item.qty, 0);
  document.getElementById('cartCount').textContent = totalCount;

  if (!state.cart.length) {
    wrap.innerHTML = '<p style="color:var(--muted)">Tu carrito esta vacio.</p>';
    document.getElementById('cartTotal').textContent = '$0.00';
    return;
  }

  wrap.innerHTML = state.cart.map((item, index) => `
    <div class="cart-item">
      <img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.title)}">
      <div>
        <strong>${escapeHtml(item.title)}</strong>
        <div class="cart-meta">${escapeHtml(item.character)} | ${escapeHtml(item.typeLabel)} | ${escapeHtml(item.size)} | ${escapeHtml(item.color)}</div>
        <div>${formatPrice(item.unitPrice)} c/u | <strong>${formatPrice(item.unitPrice * item.qty)}</strong></div>
        <div class="cart-qty">
          <button data-minus="${index}">-</button>
          <span>${item.qty}</span>
          <button data-plus="${index}">+</button>
          <button class="choice" data-remove="${index}">Quitar</button>
        </div>
      </div>
    </div>
  `).join('');

  wrap.querySelectorAll('[data-minus]').forEach(button => {
    button.addEventListener('click', () => {
      const index = Number(button.dataset.minus);
      state.cart[index].qty = Math.max(1, state.cart[index].qty - 1);
      renderCart();
    });
  });

  wrap.querySelectorAll('[data-plus]').forEach(button => {
    button.addEventListener('click', () => {
      const index = Number(button.dataset.plus);
      state.cart[index].qty += 1;
      renderCart();
    });
  });

  wrap.querySelectorAll('[data-remove]').forEach(button => {
    button.addEventListener('click', () => {
      const index = Number(button.dataset.remove);
      state.cart.splice(index, 1);
      renderCart();
    });
  });

  const total = state.cart.reduce((sum, item) => sum + item.unitPrice * item.qty, 0);
  document.getElementById('cartTotal').textContent = formatPrice(total);
}

function openCart() {
  document.getElementById('cartPanel').classList.add('open');
  document.getElementById('backdrop').classList.add('show');
  document.body.style.overflow = 'hidden';
}

function closeCart() {
  document.getElementById('cartPanel').classList.remove('open');
  document.getElementById('backdrop').classList.remove('show');
  if (!document.getElementById('productModal').classList.contains('show')) {
    document.body.style.overflow = '';
  }
}

function checkoutWhatsApp() {
  if (!state.cart.length) return;

  const total = state.cart.reduce((sum, item) => sum + item.unitPrice * item.qty, 0);
  const lines = state.cart.map(item => {
    return `- ${item.title} | Personaje: ${item.character} | Anime: ${item.anime} | ${item.typeLabel} | ${item.size} | ${item.color} | Cantidad: ${item.qty} | Total: ${formatPrice(item.unitPrice * item.qty)}`;
  }).join('\n');

  const message = encodeURIComponent(`Hola, quiero confirmar este pedido:\n${lines}\n\nSubtotal: ${formatPrice(total)}`);
  const url = `https://wa.me/${state.data.contacts.whatsapp}?text=${message}`;
  window.open(url, '_blank');
}

function bindEvents() {
  document.getElementById('cartToggle').addEventListener('click', openCart);
  document.getElementById('cartClose').addEventListener('click', closeCart);
  document.getElementById('backdrop').addEventListener('click', () => {
    closeCart();
    closeProduct();
  });

  document.getElementById('modalClose').addEventListener('click', closeProduct);
  document.getElementById('productModal').addEventListener('click', event => {
    if (event.target.id === 'productModal') closeProduct();
  });

  document.getElementById('qtyMinus').addEventListener('click', () => {
    state.qty = Math.max(1, state.qty - 1);
    updateModalPrice();
  });

  document.getElementById('qtyPlus').addEventListener('click', () => {
    state.qty += 1;
    updateModalPrice();
  });

  document.getElementById('addToCartBtn').addEventListener('click', addCurrentToCart);
  document.getElementById('checkoutBtn').addEventListener('click', checkoutWhatsApp);

  const slidePrev = document.getElementById('slidePrev');
  const slideNext = document.getElementById('slideNext');
  if (slidePrev) {
    slidePrev.addEventListener('click', () => {
      moveHeroSlide(-1);
      startHeroAutoplay();
    });
  }
  if (slideNext) {
    slideNext.addEventListener('click', () => {
      moveHeroSlide(1);
      startHeroAutoplay();
    });
  }
}

async function loadSupabaseData() {
  try {
    const { data: settings, error: settingsError } = await supabaseClient
      .from('site_settings')
      .select('*')
      .limit(1)
      .single();

    const { data: products, error: productsError } = await supabaseClient
      .from('products')
      .select('*')
      .eq('active', true)
      .order('order_index', { ascending: true });

    if (settingsError) console.error(settingsError);
    if (productsError) console.error(productsError);

    if (settings) {
      state.data.hero = {
        titlePrefix: settings.hero_title_prefix || 'BLACK',
        titleAccent: settings.hero_title_accent || 'CAT',
        subtitle: settings.hero_subtitle || 'Streetwear anime para destacar tu estilo.',
        badges: [
          settings.hero_badge_1 || 'Desde $16.99',
          settings.hero_badge_2 || 'Anime Drop',
          settings.hero_badge_3 || 'Atencion personalizada'
        ],
        image: settings.hero_image_url || ''
      };

      state.data.contacts = {
        whatsapp: settings.whatsapp || '50361900185',
        instagram: settings.instagram || 'blackcat.sivar',
        tiktok: settings.tiktok || '@blackcat.sivar',
        email: settings.email || 'blackcat2811@hotmail.com'
      };
    }

    if (Array.isArray(products)) {
      state.data.products = products.map(product => ({
        id: product.id,
        title: product.title || '',
        character: product.character || '',
        anime: product.anime || '',
        badge: product.badge || 'TOP',
        image: product.image_url || ''
      }));
    }

    applyHero();
    renderFilters();
    renderCategories();
    renderProducts();
    renderCart();
  } catch (error) {
    console.error('Error cargando Supabase:', error);
  }
}

bindEvents();
renderCart();
renderCategories();
applyHero();
renderFilters();
renderProducts();
loadSupabaseData();
